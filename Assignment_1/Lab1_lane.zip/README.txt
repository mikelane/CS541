Mike Lane
10 Oct 2016
CS 541
Lab 1


usage: clisp recth.lisp n from to aux

       n: number of disks
    from: name of starting peg
      to: name of destination peg
     aux: name of auxiliary peg

 example: clisp recth.lisp 5 A C B


